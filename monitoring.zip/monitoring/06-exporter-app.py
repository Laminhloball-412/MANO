"""
slice_exporter.py - đọc config từ /config/slices.json
Build: docker build -f Dockerfile.exporter -t nguyen0105/open5gs-slice-exporter:v1 .
"""
import os, json, time, threading, logging
from flask import Flask, jsonify
import requests
from prometheus_client import Gauge, Counter, CollectorRegistry, make_wsgi_app
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.serving import run_simple

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ── Prometheus metrics ──────────────────────────────────────
REG = CollectorRegistry()

ue_connected = Gauge(
    "open5gs_ue_connected", "UE connected to slice",
    ["slice_id", "sst", "sd", "imsi", "gnb_id", "cm_state"], registry=REG)

pdu_active = Gauge(
    "open5gs_pdu_session_active", "Active PDU session",
    ["slice_id", "sst", "sd", "imsi", "dnn", "ipv4"], registry=REG)

ue_count = Gauge(
    "open5gs_ue_count", "UE count per slice",
    ["slice_id"], registry=REG)

pdu_count = Gauge(
    "open5gs_pdu_count", "PDU session count per slice",
    ["slice_id"], registry=REG)

scrape_ok = Gauge(
    "open5gs_scrape_success", "Scrape status per slice",
    ["slice_id"], registry=REG)

# ── Cache ───────────────────────────────────────────────────
_cache = {}
_lock = threading.Lock()

def fetch(addr, path):
    try:
        r = requests.get(f"http://{addr}{path}?page=-1", timeout=3)
        r.raise_for_status()
        return r.json().get("items", [])
    except Exception as e:
        log.warning(f"{addr}{path}: {e}")
        return None

def collect(cfg):
    sid = cfg["slice_id"]
    sst = str(cfg["sst"])
    sd  = cfg["sd"]

    ues = fetch(cfg["amf"], "/ue-info")
    if ues is None:
        scrape_ok.labels(slice_id=sid).set(0)
        return

    pdus = fetch(cfg["smf"], "/pdu-info")
    if pdus is None:
        scrape_ok.labels(slice_id=sid).set(0)
        return

    # Reset metrics cũ của slice này
    for imsi in list(_cache.get(sid, {}).get("imsis", [])):
        try: ue_connected.remove(sid, sst, sd, imsi, "", "")
        except: pass

    ue_list, pdu_list = [], []

    for ue in ues:
        imsi   = ue.get("supi", "unknown")
        gnb_id = str(ue.get("gnb", {}).get("gnb_id", ""))
        state  = ue.get("cm_state", "")
        ue_connected.labels(slice_id=sid, sst=sst, sd=sd,
                            imsi=imsi, gnb_id=gnb_id, cm_state=state).set(1)
        ue_list.append({"imsi": imsi, "gnb_id": gnb_id,
                        "cm_state": state, "slice_id": sid})

    for item in pdus:
        imsi = item.get("supi", "unknown")
        for pdu in item.get("pdu", []):
            dnn  = pdu.get("dnn", "")
            ipv4 = pdu.get("ipv4", "")
            pdu_active.labels(slice_id=sid, sst=sst, sd=sd,
                              imsi=imsi, dnn=dnn, ipv4=ipv4).set(1)
            pdu_list.append({"imsi": imsi, "dnn": dnn,
                             "ipv4": ipv4, "slice_id": sid})

    ue_count.labels(slice_id=sid).set(len(ue_list))
    pdu_count.labels(slice_id=sid).set(len(pdu_list))
    scrape_ok.labels(slice_id=sid).set(1)

    with _lock:
        _cache[sid] = {"ues": ue_list, "pdus": pdu_list,
                       "imsis": {u["imsi"] for u in ue_list}}

    log.info(f"[{sid}] UEs={len(ue_list)} PDUs={len(pdu_list)}")

def loop(slices, interval):
    while True:
        threads = [threading.Thread(target=collect, args=(s,), daemon=True)
                   for s in slices]
        for t in threads: t.start()
        for t in threads: t.join(timeout=10)
        time.sleep(interval)

# ── Flask REST API ──────────────────────────────────────────
app = Flask(__name__)

@app.route("/health")
def health(): return jsonify({"status": "ok"})

@app.route("/imsi-by-slice")
def all_slices():
    with _lock:
        return jsonify({sid: {"ue_count": len(d["ues"]), "ues": d["ues"],
                              "pdu_count": len(d["pdus"]), "pdus": d["pdus"]}
                        for sid, d in _cache.items()})

@app.route("/imsi-by-slice/<sid>")
def one_slice(sid):
    with _lock:
        d = _cache.get(sid)
    if not d: return jsonify({"error": "not found"}), 404
    return jsonify({"slice_id": sid, "ue_count": len(d["ues"]),
                    "ues": d["ues"], "pdus": d["pdus"]})

@app.route("/imsi/<imsi>")
def find_imsi(imsi):
    found = []
    with _lock:
        for d in _cache.values():
            for ue in d["ues"]:
                if ue["imsi"] in (imsi, f"imsi-{imsi}"):
                    found.append(ue)
    if not found: return jsonify({"status": "not_found"}), 404
    return jsonify({"imsi": imsi, "status": "connected", "slices": found})

app.wsgi_app = DispatcherMiddleware(app.wsgi_app,
    {"/metrics": make_wsgi_app(registry=REG)})

if __name__ == "__main__":
    cfg_file = os.getenv("CONFIG_FILE", "/config/slices.json")
    interval = int(os.getenv("SCRAPE_INTERVAL", "15"))
    port     = int(os.getenv("PORT", "8080"))

    with open(cfg_file) as f:
        slices = json.load(f)

    log.info(f"Loaded {len(slices)} slice(s): {[s['slice_id'] for s in slices]}")

    # Scrape lần đầu ngay lập tức
    for s in slices: collect(s)

    threading.Thread(target=loop, args=(slices, interval), daemon=True).start()

    log.info(f"Exporter running on :{port}")
    run_simple("0.0.0.0", port, app.wsgi_app)
